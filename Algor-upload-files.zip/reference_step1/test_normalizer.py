import copy
import json
from pathlib import Path
import unittest
from normalizer import normalize

class NormalizationTests(unittest.TestCase):
    def setUp(self):
        self.c = json.loads(Path(__file__).with_name('catalog.demo.json').read_text())
    def test_all_ordinal_values(self):
        self.assertEqual([normalize(self.c, 'DEMO_ORDINAL', f'level{i}')['score'] for i in range(1,6)], [0,25,50,75,100])
    def test_checklist_values(self):
        self.assertEqual([normalize(self.c, 'DEMO_CHECKLIST', a, verified=True)['score'] for a in ['pending','partial','complete']], [0,50,100])
    def test_missing_not_zero(self):
        r=normalize(self.c,'DEMO_ORDINAL',None)
        self.assertEqual((r['status'],r['score']),('missing',None))
    def test_invalid_answers(self):
        for a in ['unknown','',1,True,[],{}]:
            r=normalize(self.c,'DEMO_ORDINAL',a)
            self.assertEqual((r['status'],r['score']),('validation_error',None))
    def test_unknown_indicator(self):
        self.assertEqual(normalize(self.c,'UNKNOWN','level1')['reason'],'unknown_indicator')
    def test_unreviewed_order(self):
        self.c['indicators']['DEMO_ORDINAL']['order_reviewed']=False
        self.assertIsNone(normalize(self.c,'DEMO_ORDINAL','level1')['score'])
    def test_duplicate_codes(self):
        self.c['indicators']['DEMO_ORDINAL']['ordered_codes']=['x']*5
        self.assertIsNone(normalize(self.c,'DEMO_ORDINAL','x')['score'])
    def test_nominal_scale(self):
        self.c['indicators']['DEMO_ORDINAL']['scale']='nominal'
        self.assertEqual(normalize(self.c,'DEMO_ORDINAL','level1')['reason'],'unsupported_scale')
    def test_version_mismatch(self):
        self.c['methodology_version']='9'
        self.assertEqual(normalize(self.c,'DEMO_ORDINAL','level1')['reason'],'version_mismatch')
    def test_verification_not_inferred(self):
        for verified in [False, 'true', 1, None]:
            self.assertEqual(normalize(self.c,'DEMO_CHECKLIST','complete',verified=verified)['status'],'unverified')
        self.assertEqual(normalize(self.c,'DEMO_CHECKLIST','complete',verified=True)['status'],'ok')
    def test_repeatable_and_no_mutation(self):
        before=copy.deepcopy(self.c)
        self.assertEqual(normalize(self.c,'DEMO_ORDINAL','level3'),normalize(self.c,'DEMO_ORDINAL','level3'))
        self.assertEqual(before,self.c)

if __name__=='__main__': unittest.main()
