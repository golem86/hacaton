"""Author-defined demo normalization v0.1. Synthetic data only; no aggregation."""
import json
from pathlib import Path

VERSION = '0.1'

def normalize(catalog, indicator_id, answer_code, *, verified=False):
    result = dict(methodology_version=VERSION, indicator_id=indicator_id,
                  answer_code=answer_code, score=None, status='validation_error',
                  verified=verified is True, rule_id=None, reason=None)
    if catalog.get('methodology_version') != VERSION:
        return dict(result, reason='version_mismatch')
    indicator = catalog.get('indicators', {}).get(indicator_id)
    if not indicator:
        return dict(result, reason='unknown_indicator')
    scale = indicator.get('scale')
    if scale == 'ordinal5':
        codes = indicator.get('ordered_codes', [])
        if (indicator.get('order_reviewed') is not True or len(codes) != 5
                or any(not isinstance(c, str) or not c for c in codes)
                or len(set(codes)) != 5):
            return dict(result, reason='invalid_or_unreviewed_order')
        mapping = {code: i * 25 for i, code in enumerate(codes)}
        result['rule_id'] = 'author_ordinal5_v0.1'
    elif scale == 'checklist3':
        mapping = {'pending': 0, 'partial': 50, 'complete': 100}
        result['rule_id'] = 'author_checklist3_v0.1'
    else:
        return dict(result, reason='unsupported_scale')
    if answer_code is None:
        return dict(result, status='missing', reason='no_answer')
    if not isinstance(answer_code, str) or answer_code not in mapping:
        return dict(result, reason='unknown_answer_code')
    result['score'] = mapping[answer_code]
    result['status'] = 'ok'
    result['reason'] = 'explicit_code_mapping'
    if indicator.get('requires_verification') and verified is not True:
        result['status'] = 'unverified'
        result['reason'] = 'score_is_not_confirmed_evidence'
    return result

if __name__ == '__main__':
    root = Path(__file__).parent
    catalog = json.loads((root / 'catalog.demo.json').read_text())
    answers = json.loads((root / 'answers.synthetic.json').read_text())
    print(json.dumps([normalize(catalog, **a) for a in answers], ensure_ascii=False, indent=2))
