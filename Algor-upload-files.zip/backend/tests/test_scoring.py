from copy import deepcopy
from fractions import Fraction
import json
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError
from app.services.scoring import (Assessment, calculate_index, normalize_answer,
                                          checklist_score)
from app.services.analytics import (compare_sources, compare_objective,
                                            compare_periods)
from app.services.recommendations import generate_recommendations
from app.services.tracker import transition, is_overdue
from app.demo_api import app

EXAMPLES = Path(__file__).resolve().parents[2] / 'examples'


@pytest.fixture
def assessments():
    return json.loads((EXAMPLES / 'assessments.synthetic.json').read_text())


@pytest.fixture
def facts():
    return json.loads((EXAMPLES / 'objective.synthetic.json').read_text())


@pytest.mark.parametrize('code,score', [('level1',0),('level2',25),('level3',50),('level4',75),('level5',100),(None,None)])
def test_normalize(code, score):
    assert normalize_answer('education', code) == score


@pytest.mark.parametrize('code', ['unknown', '', True, 1, [], {}])
def test_reject_unknown_answer(code):
    with pytest.raises(ValueError):
        normalize_answer('education', code)


def test_unknown_indicator():
    with pytest.raises(ValueError):
        normalize_answer('DEMO_ORDINAL', 'level1')


def test_hand_calculation(assessments):
    reports = [calculate_index(a) for a in assessments]
    assert [r['index_exact'] for r in reports] == ['50', '75', '125/3']
    assert [c['score'] for c in reports[0]['components']] == [75, 45, 30]
    assert reports[2]['index'] == 41.67
    assert sum(Fraction(c['contribution_exact']) for c in reports[0]['components']) == 50


@pytest.mark.parametrize('level,expected', [(1,0),(5,100)])
def test_bounds(assessments, level, expected):
    a = assessments[0]
    for row in a['observations']:
        row['counts'] = {f'level{i}': 10 if i==level else 0 for i in range(1,6)}
    assert calculate_index(a)['index'] == expected


def test_monotonicity(assessments):
    a = assessments[0]
    old = Fraction(calculate_index(a)['index_exact'])
    a['observations'][0]['counts']['level3'] -= 1
    a['observations'][0]['counts']['level4'] += 1
    assert Fraction(calculate_index(a)['index_exact']) - old == Fraction(25,30)


def test_missing_component_no_weight_redistribution(assessments):
    a = assessments[0]
    a['observations'].pop()
    r = calculate_index(a)
    assert r['index'] is None
    assert r['coverage'] == {'eligible_indicators':2,'expected_indicators':3}
    assert r['components'][0]['component_weight'] == '1/3'
    assert r['components'][-1]['status'] == 'missing'


def test_no_answers(assessments):
    a = assessments[0]
    for row in a['observations']:
        row['counts'] = {f'level{i}':0 for i in range(1,6)}
        row['missing_count'] = 10
    r = calculate_index(a)
    assert r['index'] is None
    assert all(c['status']=='missing' for c in r['components'])


@pytest.mark.parametrize('valid,status', [(4,'suppressed'),(7,'insufficient_data'),(8,'ok')])
def test_quality_boundaries(assessments, valid, status):
    a = assessments[0]
    a['observations'][0]['counts'] = {f'level{i}':valid if i==5 else 0 for i in range(1,6)}
    a['observations'][0]['missing_count'] = 10-valid
    c = calculate_index(a)['components'][0]
    assert c['status']==status
    if status=='suppressed':
        for key in ['score','score_exact','distribution','valid_count','missing_count','response_rate','contribution']:
            assert c[key] is None


def test_missing_excluded_not_zero(assessments):
    a = assessments[0]
    a['observations'][0]['counts'] = dict(level1=0,level2=0,level3=0,level4=0,level5=8)
    a['observations'][0]['missing_count']=2
    assert calculate_index(a)['components'][0]['score'] == 100


@pytest.mark.parametrize('bad', [-1,True,'2',1.5,float('nan'),float('inf')])
def test_bad_counts(assessments,bad):
    assessments[0]['observations'][0]['counts']['level1']=bad
    with pytest.raises(ValidationError):calculate_index(assessments[0])


@pytest.mark.parametrize('key,value', [('synthetic',False),('synthetic',1),('source','unknown'),('methodology_version','0.1'),('catalog_version','unknown'),('schema_version','0.1')])
def test_contract_rejects(assessments,key,value):
    assessments[0][key]=value
    with pytest.raises(ValidationError):calculate_index(assessments[0])


def test_duplicate_indicator(assessments):
    a=assessments[0];a['observations'].append(deepcopy(a['observations'][0]))
    with pytest.raises(ValidationError):calculate_index(a)


def test_count_consistency(assessments):
    assessments[0]['cohort_size']=11
    with pytest.raises(ValidationError):calculate_index(assessments[0])


def test_no_person_fields(assessments):
    assessments[0]['respondent_email']='synthetic@example.invalid'
    with pytest.raises(ValidationError):calculate_index(assessments[0])


@pytest.mark.parametrize('change', ['flag','refs'])
def test_expert_requires_verified_evidence(assessments,change):
    a=assessments[2]
    if change=='flag':a['observations'][0]['evidence_verified']=False
    else:a['observations'][0]['evidence_refs']=[]
    assert calculate_index(a)['index'] is None
    assert calculate_index(a)['components'][0]['status']=='unverified'


def test_deterministic_and_immutable(assessments):
    a=assessments[0];before=deepcopy(a)
    r=calculate_index(a)
    assert calculate_index(a)==r and a==before
    a['observations'].reverse()
    assert calculate_index(a)==r


def test_source_gap_exact_threshold(assessments):
    comparisons=compare_sources([assessments[0],assessments[2]])
    assert [r['gap_points'] for r in comparisons]==[25,-5,5]
    assert [r['flag'] for r in comparisons]==[True,False,False]


@pytest.mark.parametrize('key,value',[('unit_id','SYN_OTHER'),('period','2026-Q3'),('population_id','SYN_OTHER')])
def test_mismatched_sources_not_compared(assessments,key,value):
    assessments[2][key]=value
    assert all(x['status']=='not_comparable' and x['gap_points'] is None for x in compare_sources([assessments[0],assessments[2]]))


def test_duplicate_source_not_compared(assessments):
    with pytest.raises(ValueError):compare_sources([assessments[0],assessments[0]])


def test_checklist_not_mixed_with_index(assessments,facts):
    before=calculate_index(assessments[0])
    c=compare_objective(assessments[0],facts[0])
    assert c['objective_value']==50 and c['gap_points'] is None
    assert c['assessment_score']==75
    assert calculate_index(assessments[0])==before


@pytest.mark.parametrize('code,value',[('pending',0),('partial',50),('complete',100)])
def test_checklist_mapping(code,value):
    assert checklist_score(code,verified=True)['score']==value
    assert checklist_score(code,verified='true')=={'score':None,'status':'unverified'}


def test_objective_rate(assessments,facts):
    c=compare_objective(assessments[0],facts[-1])
    assert c['objective_value']==60 and c['objective_unit']=='percent'
    assert c['gap_points'] is None


def test_zero_denominator(assessments,facts):
    facts[-1]['denominator']=0
    with pytest.raises(ValidationError):compare_objective(assessments[0],facts[-1])


def test_unverified_objective(assessments,facts):
    facts[0]['verified']=False
    assert compare_objective(assessments[0],facts[0])['objective_value'] is None


def test_objective_wrong_period(assessments,facts):
    facts[0]['period']='2026-Q3'
    c=compare_objective(assessments[0],facts[0])
    assert c['status']=='not_comparable' and c['objective_value'] is None


def test_trend(assessments):
    a=assessments[0];b=deepcopy(a);b['period']='2027-Q1'
    assert compare_periods(a,b)['change_points']==0
    b['source']='self_working_group'
    assert compare_periods(a,b)['status']=='not_comparable'


def test_rules_and_repeatability(assessments,facts):
    r=generate_recommendations(assessments[0],assessments[1:],facts)
    assert r==generate_recommendations(assessments[0],assessments[1:],facts)
    assert len({x['id'] for x in r})==len(r)
    assert all(x['status']=='proposed' and x['owner_id'] is None for x in r)
    rules=[x['rule_id'] for x in r]
    assert rules.count('LOW_SCORE_LT_50_V1')==2
    assert rules.count('SOURCE_GAP_GE_25_V1')==6
    assert rules.count('CHECKLIST_INCOMPLETE_V1')==2
    assert rules.count('TRAINING_COVERAGE_LT_80_V1')==1


def test_exact_score_50_does_not_trigger_low_score(assessments):
    rules=generate_recommendations(assessments[2])
    assert [r['indicator_id'] for r in rules if r['rule_id']=='LOW_SCORE_LT_50_V1']==['risk']


def test_human_tracker(assessments):
    r=generate_recommendations(assessments[0])[0];original=deepcopy(r)
    args=dict(actor_id='SYN_MANAGER',human_decision=True,on_date='2026-11-16',reason='Синтетичне рішення')
    with pytest.raises(ValueError):transition(r,'accepted',**args)
    accepted=transition(r,'accepted',owner_id='SYN_OWNER',due_date='2026-12-01',**args)
    assert r==original and accepted['owner_id']=='SYN_OWNER'
    assert not is_overdue(accepted,as_of='2026-12-01')
    assert is_overdue(accepted,as_of='2026-12-02')
    with pytest.raises(ValueError):transition(accepted,'completed',**args)
    active=transition(accepted,'in_progress',**args)
    done=transition(active,'completed',evidence_refs=('synthetic://done',),**args)
    with pytest.raises(ValueError):transition(done,'verified',evidence_refs=('synthetic://checked',),**args)
    verified=transition(done,'verified',evidence_refs=('synthetic://checked',),next_assessment_id='SYN_NEXT',**args)
    assert verified['status']=='verified' and len(verified['history'])==4
    assert calculate_index(assessments[0])['index']==50


def test_automatic_acceptance_rejected(assessments):
    r=generate_recommendations(assessments[0])[0]
    with pytest.raises(ValueError):transition(r,'accepted',actor_id='SYN_BOT',human_decision=False,on_date='2026-11-16',reason='test',owner_id='SYN_OWNER',due_date='2026-12-01')


def test_fastapi_contract(assessments):
    client=TestClient(app)
    response=client.post('/api/demo/index',json=assessments[0])
    assert response.status_code==200 and response.json()['index']==50
    assessments[0]['synthetic']=False
    assert client.post('/api/demo/index',json=assessments[0]).status_code==422
