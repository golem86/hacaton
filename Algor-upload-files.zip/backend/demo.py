"""Run from repository root: python -m backend.demo."""
import json
from pathlib import Path
from backend.app.services.scoring import calculate_index
from backend.app.services.analytics import compare_sources, compare_objective
from backend.app.services.recommendations import generate_recommendations


def demo():
    root = Path(__file__).resolve().parents[1] / 'examples'
    assessments = json.loads((root / 'assessments.synthetic.json').read_text())
    facts = json.loads((root / 'objective.synthetic.json').read_text())
    return {'reports': [calculate_index(a) for a in assessments],
            'comparisons': compare_sources(assessments),
            'objective_context': [compare_objective(assessments[0], f) for f in facts],
            'recommendations': generate_recommendations(assessments[0], assessments[1:], facts)}


if __name__ == '__main__':
    print(json.dumps(demo(), ensure_ascii=False, indent=2))
