"""Author-defined demo-0.2. Only synthetic, aggregate data; no AI calls."""
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, StrictBool, model_validator

VERSION = 'demo-0.2'
CATALOG_VERSION = 'demo-catalog-0.2'
MIN_GROUP_SIZE = 5  # Demonstration setting, not a guarantee of anonymity.
MIN_RESPONSE_RATE = Fraction(4, 5)  # Author-defined 80% per question.
INDICATORS = {'education': 'culture', 'officer': 'system', 'risk': 'accountability'}
SCORES = {'level1': 0, 'level2': 25, 'level3': 50, 'level4': 75, 'level5': 100}
CHECKLIST_SCORES = {'pending': 0, 'partial': 50, 'complete': 100}
CATALOG_PATH = Path(__file__).resolve().parents[3] / 'docs/catalog.demo.json'
CATALOG_HASH = sha256(CATALOG_PATH.read_bytes()).hexdigest()
RULE_CONFIG = {'version': VERSION, 'catalog_sha256': CATALOG_HASH,
               'min_group_size': MIN_GROUP_SIZE, 'min_response_rate': '4/5',
               'component_weights': {c: '1/3' for c in INDICATORS.values()},
               'scores': SCORES, 'require_all_components': True,
               'gap_threshold': 25, 'low_score_threshold': 50}
CONFIG_HASH = sha256(json.dumps(RULE_CONFIG, sort_keys=True).encode()).hexdigest()
Count = Annotated[int, Field(strict=True, ge=0)]
Identifier = Annotated[str, Field(strict=True, min_length=1, max_length=120)]
IndicatorId = Literal['education', 'officer', 'risk']
Source = Literal['self_staff', 'self_working_group', 'expert']


class Contract(BaseModel):
    model_config = ConfigDict(extra='forbid', frozen=True)


class Counts(Contract):
    level1: Count
    level2: Count
    level3: Count
    level4: Count
    level5: Count


class Observation(Contract):
    indicator_id: IndicatorId
    counts: Counts
    missing_count: Count = 0
    evidence_verified: StrictBool = False
    evidence_refs: tuple[Identifier, ...] = ()


class Assessment(Contract):
    schema_version: Literal['0.2']
    methodology_version: Literal['demo-0.2']
    catalog_version: Literal['demo-catalog-0.2']
    synthetic: StrictBool
    assessment_id: Identifier
    unit_id: Identifier
    period: Identifier  # Canonical cycle ID, same for all compared sources.
    population_id: Identifier  # Stable target population, not respondent identity.
    source: Source
    cohort_size: Annotated[int, Field(strict=True, ge=1)]
    observations: tuple[Observation, ...]

    @model_validator(mode='after')
    def check_scope(self):
        if not self.synthetic:
            raise ValueError('Only synthetic data are supported')
        ids = [o.indicator_id for o in self.observations]
        if len(ids) != len(set(ids)):
            raise ValueError('Duplicate indicator_id')
        for row in self.observations:
            if sum(row.counts.model_dump().values()) + row.missing_count != self.cohort_size:
                raise ValueError('counts + missing_count must equal cohort_size')
        return self


def normalize_answer(indicator_id: str, answer_code: str | None) -> int | None:
    """A missing answer remains None. Unknown/nominal codes are errors."""
    if indicator_id not in INDICATORS:
        raise ValueError('Unknown indicator')
    if answer_code is None:
        return None
    if not isinstance(answer_code, str) or answer_code not in SCORES:
        raise ValueError('Unknown answer code')
    return SCORES[answer_code]


def checklist_score(answer_code: str | None, *, verified: bool = False) -> dict:
    """Separate contextual score. Never added to Integrity Index."""
    if answer_code is None:
        return {'score': None, 'status': 'missing'}
    if not isinstance(answer_code, str) or answer_code not in CHECKLIST_SCORES:
        raise ValueError('Unknown checklist code')
    return {'score': CHECKLIST_SCORES[answer_code] if verified is True else None,
            'status': 'ok' if verified is True else 'unverified'}


def exact(value: Fraction | None) -> str | None:
    return str(value) if value is not None else None


def display(value: Fraction | None) -> float | None:
    """Presentation only; decisions always use exact fractions."""
    return round(float(value), 2) if value is not None else None


def calculate_index(payload: Assessment | dict) -> dict:
    data = payload if isinstance(payload, Assessment) else Assessment.model_validate(payload)
    rows = {row.indicator_id: row for row in data.observations}
    components, eligible = [], []
    for indicator_id, component_id in INDICATORS.items():
        row = rows.get(indicator_id)
        score = None
        valid = sum(row.counts.model_dump().values()) if row else 0
        response_rate = Fraction(valid, data.cohort_size)
        if row is None or valid == 0:
            status = 'missing'
        elif data.source != 'expert' and valid < MIN_GROUP_SIZE:
            status = 'suppressed'
        elif response_rate < MIN_RESPONSE_RATE:
            status = 'insufficient_data'
        elif data.source == 'expert' and (not row.evidence_verified or not row.evidence_refs):
            status = 'unverified'
        else:
            status = 'ok'
            score = Fraction(sum(SCORES[k] * v for k, v in row.counts.model_dump().items()), valid)
            eligible.append(score)
        # Small groups expose neither counts nor intermediate scores.
        hidden = status == 'suppressed'
        components.append({
            'component_id': component_id, 'criterion_id': indicator_id,
            'indicator_id': indicator_id, 'status': status,
            'score': display(score), 'score_exact': exact(score),
            'component_weight': '1/3', 'criterion_weight': '1', 'indicator_weight': '1',
            'contribution': display(score / 3) if score is not None else None,
            'contribution_exact': exact(score / 3) if score is not None else None,
            'valid_count': None if hidden else valid,
            'missing_count': None if hidden else (row.missing_count if row else data.cohort_size),
            'response_rate': None if hidden else display(response_rate),
            'response_rate_exact': None if hidden else exact(response_rate),
            'distribution': row.counts.model_dump() if status == 'ok' else None,
            'rule_id': 'author_ordinal5_equal_components_v0.2',
        })
    index = sum(eligible, Fraction(0)) / 3 if len(eligible) == 3 else None
    canonical = data.model_dump(mode='json')
    canonical['observations'].sort(key=lambda x: x['indicator_id'])
    input_hash = sha256(json.dumps(canonical, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    return {
        'schema_version': '0.2', 'methodology_version': VERSION,
        'catalog_version': CATALOG_VERSION, 'synthetic': True,
        'assessment_id': data.assessment_id, 'unit_id': data.unit_id,
        'period': data.period, 'population_id': data.population_id, 'source': data.source,
        'index_label': 'Integrity Index demo — ' + data.source,
        'status': 'ok' if index is not None else 'insufficient_data',
        'index': display(index), 'index_exact': exact(index),
        'coverage': {'eligible_indicators': len(eligible), 'expected_indicators': 3},
        'components': components,
        'audit': {'input_sha256': input_hash, 'config_sha256': CONFIG_HASH,
                  'catalog_sha256': CATALOG_HASH, 'engine_version': VERSION},
    }
