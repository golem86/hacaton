"""Deterministic suggestions. All start as proposed; only humans accept them."""
from fractions import Fraction
from hashlib import sha256
import json
from .analytics import ObjectiveFact, compare_objective, compare_sources
from .scoring import Assessment, calculate_index

ACTIONS = {
    'education': 'Переглянути потреби в навчанні, погодити план і спосіб перевірки знань.',
    'officer': 'Перевірити повноваження, ресурси та гарантії незалежності уповноваженого.',
    'risk': 'Переглянути реєстр ризиків, визначення виконавців і моніторинг заходів.',
}


def generate_recommendations(primary: Assessment | dict,
                             others: list[Assessment | dict] | None = None,
                             facts: list[ObjectiveFact | dict] | None = None) -> list[dict]:
    report = calculate_index(primary)
    output = []

    def add(rule_id, indicator_id, reason, action, evidence):
        identity = {'assessment_id': report['assessment_id'],
                    'input_sha256': report['audit']['input_sha256'],
                    'config_sha256': report['audit']['config_sha256'],
                    'rule_id': rule_id, 'indicator_id': indicator_id, 'evidence': evidence}
        rid = sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()[:24]
        output.append({'id': rid, 'assessment_id': report['assessment_id'],
                       'methodology_version': report['methodology_version'],
                       'rule_id': rule_id, 'indicator_id': indicator_id,
                       'reason': reason, 'suggested_action': action, 'evidence': evidence,
                       'status': 'proposed', 'owner_id': None, 'due_date': None,
                       'requires_human_decision': True})

    for row in report['components']:
        id = row['indicator_id']
        if row['status'] != 'ok':
            add('DATA_QUALITY_V1', id, 'Недостатньо допустимих даних: ' + row['status'],
                'Перевірити повноту та допустимість даних без розкриття малих груп.',
                {'status': row['status']})
        elif Fraction(row['score_exact']) < 50:
            add('LOW_SCORE_LT_50_V1', id,
                f"Оцінка {row['score']} нижча за авторський поріг 50.",
                ACTIONS[id], {'score_exact': row['score_exact'], 'threshold': 50})
    for gap in compare_sources([primary, *(others or [])]):
        if gap['flag']:
            add('SOURCE_GAP_GE_25_V1', gap['indicator_id'],
                f"Розрив {gap['gap_points']} бала між {gap['left_source']} і {gap['right_source']}.",
                'Перевірити трактування питання та докази; обговорити причини розбіжності.', gap)
    seen_metrics = set()
    for fact in facts or []:
        context = compare_objective(primary, fact)
        if context['metric_id'] in seen_metrics:
            raise ValueError('Duplicate objective metric')
        seen_metrics.add(context['metric_id'])
        if context['status'] == 'not_comparable':
            continue
        if context['status'] != 'ok':
            add('OBJECTIVE_DATA_QUALITY_V1', context['indicator_id'],
                'Фактичний показник відсутній або не підтверджений.',
                'Отримати та перевірити підтвердні матеріали.', context)
        elif context['objective_unit'] == 'demo_checklist_points' and Fraction(context['objective_exact']) < 100:
            add('CHECKLIST_INCOMPLETE_V1', context['indicator_id'],
                'Пов’язаний пункт чек-листа не впроваджено повністю.',
                'Перевірити невиконану частину заходу та запропонувати план усунення прогалин.', context)
        elif context['metric_id'] == 'training_coverage' and Fraction(context['objective_exact']) < 80:
            add('TRAINING_COVERAGE_LT_80_V1', 'education',
                'Охоплення навчанням нижче авторського демонстраційного орієнтира 80%.',
                'З’ясувати причини неохоплення та запропонувати додаткове навчання.', context)
    return sorted(output, key=lambda r: r['id'])
