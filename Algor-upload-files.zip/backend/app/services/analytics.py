"""Comparisons of like measurements; contextual facts remain separate."""
from fractions import Fraction
from itertools import combinations
from typing import Annotated, Literal
from pydantic import Field, StrictBool, model_validator
from .scoring import (Assessment, Contract, Count, Identifier, IndicatorId,
                      calculate_index, checklist_score, display, exact)

GAP_THRESHOLD = Fraction(25)  # Author-defined, in points on the 0–100 scale.


class ObjectiveFact(Contract):
    synthetic: StrictBool
    unit_id: Identifier
    period: Identifier
    population_id: Identifier
    indicator_id: IndicatorId
    metric_id: Literal['B_2_6', 'B_2_1', 'B_2_4', 'training_coverage']
    verified: StrictBool = False
    evidence_refs: tuple[Identifier, ...] = ()
    answer_code: Literal['pending', 'partial', 'complete'] | None = None
    numerator: Count | None = None
    denominator: Annotated[int, Field(strict=True, ge=1)] | None = None

    @model_validator(mode='after')
    def check_metric(self):
        if not self.synthetic:
            raise ValueError('Only synthetic facts are supported')
        mapping = {'B_2_6': 'education', 'B_2_1': 'officer',
                   'B_2_4': 'risk', 'training_coverage': 'education'}
        if mapping[self.metric_id] != self.indicator_id:
            raise ValueError('Metric/indicator mismatch')
        if self.metric_id == 'training_coverage':
            if self.answer_code is not None:
                raise ValueError('A rate has no checklist answer_code')
            if (self.numerator is None) != (self.denominator is None):
                raise ValueError('Provide both numerator and denominator, or neither')
            if self.numerator is not None and self.numerator > self.denominator:
                raise ValueError('Numerator exceeds denominator')
        elif self.numerator is not None or self.denominator is not None:
            raise ValueError('A checklist item has no numerator/denominator')
        return self


def compare_sources(assessments: list[Assessment | dict]) -> list[dict]:
    reports = [calculate_index(a) for a in assessments]
    if len({r['source'] for r in reports}) != len(reports):
        raise ValueError('Provide one assessment per source')
    output = []
    for left, right in combinations(reports, 2):
        comparable = all(left[k] == right[k] for k in
                         ('unit_id', 'period', 'population_id', 'methodology_version', 'catalog_version'))
        for a, b in zip(left['components'], right['components']):
            gap = None
            if not comparable:
                status = 'not_comparable'
            elif a['status'] != 'ok' or b['status'] != 'ok':
                status = 'unavailable'
            else:
                status = 'ok'
                gap = Fraction(a['score_exact']) - Fraction(b['score_exact'])
            output.append({'left_source': left['source'], 'right_source': right['source'],
                           'left_assessment_id': left['assessment_id'],
                           'right_assessment_id': right['assessment_id'],
                           'indicator_id': a['indicator_id'], 'status': status,
                           'gap_points': display(gap), 'gap_exact': exact(gap),
                           'flag': abs(gap) >= GAP_THRESHOLD if gap is not None else None,
                           'threshold_points': 25,
                           'meaning': 'Signal for review; not evidence of dishonesty'})
    return output


def compare_objective(assessment: Assessment | dict, fact: ObjectiveFact | dict) -> dict:
    report = calculate_index(assessment)
    fact = fact if isinstance(fact, ObjectiveFact) else ObjectiveFact.model_validate(fact)
    comparable = all(report[k] == getattr(fact, k) for k in ('unit_id', 'period', 'population_id'))
    row = next(r for r in report['components'] if r['indicator_id'] == fact.indicator_id)
    verified = fact.verified and bool(fact.evidence_refs)
    value = None
    if not comparable:
        status = 'not_comparable'
    elif fact.metric_id == 'training_coverage':
        status = 'missing' if fact.numerator is None else ('ok' if verified else 'unverified')
        if status == 'ok':
            value = Fraction(100 * fact.numerator, fact.denominator)
    else:
        result = checklist_score(fact.answer_code, verified=verified)
        status = result['status']
        if result['score'] is not None:
            value = Fraction(result['score'])
    return {'indicator_id': fact.indicator_id, 'metric_id': fact.metric_id,
            'status': status, 'assessment_id': report['assessment_id'],
            'assessment_status': row['status'], 'assessment_score': row['score'] if comparable else None,
            'objective_value': display(value), 'objective_exact': exact(value),
            'objective_unit': 'percent' if fact.metric_id == 'training_coverage' else 'demo_checklist_points',
            'comparison_type': 'context_only', 'gap_points': None,
            'reason': 'Different constructs: no subtraction or automatic index correction'}


def compare_periods(before: Assessment | dict, after: Assessment | dict) -> dict:
    a, b = calculate_index(before), calculate_index(after)
    same = all(a[k] == b[k] for k in ('unit_id', 'population_id', 'source', 'catalog_version', 'methodology_version'))
    gap = None
    if not same or a['period'] == b['period']:
        status = 'not_comparable'
    elif a['index'] is None or b['index'] is None:
        status = 'unavailable'
    else:
        status = 'ok'
        gap = Fraction(b['index_exact']) - Fraction(a['index_exact'])
    return {'status': status, 'before_period': a['period'], 'after_period': b['period'],
            'change_points': display(gap), 'change_exact': exact(gap),
            'note': 'Caller supplies chronological order; association is not causation'}
