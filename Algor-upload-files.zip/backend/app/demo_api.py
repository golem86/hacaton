"""Local integration example; not an authenticated production API."""
from fastapi import FastAPI
from .services.scoring import Assessment, calculate_index

app = FastAPI(title='Integrity Index — synthetic demo', version='0.2')


@app.post('/api/demo/index')
def index(payload: Assessment):
    return calculate_index(payload)
